package com.abhisekseal.enno2020mscs001.curaj.newsfeedapp;



import android.os.Bundle;

import com.kwabenaberko.newsapilib.NewsApiClient;

public class MainActivity extends AppCompatActivity {

    String apikey="25329bcc8c39480f9a70307e3980b6d8";
    NewsApiClient newsApiClient = new NewsApiClient("YOUR_API_KEY");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }
}